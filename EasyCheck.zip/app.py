from flask import Flask, render_template, request, redirect, url_for, flash
import sqlite3
import os
from scripts.camera import capture_image
from scripts.omr import process_omr

app = Flask(__name__)
app.secret_key = 'your_secret_key'
UPLOAD_FOLDER = 'uploads/'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/dashboard', methods=['GET', 'POST'])
def dashboard():
    if request.method == 'POST':
        if 'capture' in request.form:
            capture_image(os.path.join(app.config['UPLOAD_FOLDER'], 'captured_image.jpg'))
            flash('Image captured successfully!', 'success')
        elif 'process' in request.form:
            result = process_omr(os.path.join(app.config['UPLOAD_FOLDER'], 'captured_image.jpg'))
            conn = sqlite3.connect('database.db')
            cursor = conn.cursor()
            cursor.execute("INSERT INTO students (name, score, total_items, status, file_image) VALUES (?, ?, ?, ?, ?)",
                           ('Student Name', result['score'], result['total_items'], result['status'], 'uploads/captured_image.jpg'))
            conn.commit()
            conn.close()
            flash('Image processed and result saved!', 'success')
    return render_template('dashboard.html')
